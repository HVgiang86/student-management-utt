package vn.edu.utt.uttqlsv.model

object Gender {
    const val MALE = true
    const val FEMALE = false
}
